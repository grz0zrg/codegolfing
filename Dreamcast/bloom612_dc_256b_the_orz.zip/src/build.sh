#!/bin/sh
set -eu
/opt/toolchains/dc/sh-elf/bin/sh-elf-as -little $1.s -o $1.o
/opt/toolchains/dc/sh-elf/bin/sh-elf-ld --oformat elf32-shl -Ttext 0x8c010000 $1.o -o $1.elf
/opt/toolchains/dc/sh-elf/bin/sh-elf-objcopy -R .stack -O binary $1.elf $1.bin
/opt/toolchains/dc/sh-elf/bin/sh-elf-objdump -m sh4 -EL -b binary --adjust-vma=0x8c010000 -D $1.bin
wc -c $1.bin
/opt/toolchains/dc/mkdcdisc/builddir/mkdcdisc -v 3 -e $1.elf -o $1.cdi -n "" -m
# cd /tmp && find . -maxdepth 2 -name '0.0' -delete
~/sizecoding/dreamcast/redream/redream $1.cdi
